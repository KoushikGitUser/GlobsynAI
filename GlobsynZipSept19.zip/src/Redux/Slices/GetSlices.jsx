import { createSlice } from "@reduxjs/toolkit";


export const GetSlice = createSlice({
    name:"GetSlice",
    initialState:{},
    reducers:{},
    extraReducers:(builders)=>{

    }
})

export default GetSlice;