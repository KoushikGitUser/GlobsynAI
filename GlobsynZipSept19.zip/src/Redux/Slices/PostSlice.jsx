import { createSlice } from "@reduxjs/toolkit";


export const PostSlice = createSlice({
    name:"PostSlice",
    initialState:{},
    reducers:{},
    extraReducers:(builders)=>{

    }
})

export default PostSlice;