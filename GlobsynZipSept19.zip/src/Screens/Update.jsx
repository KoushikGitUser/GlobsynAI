import React from 'react'

export default function Update() {
  return (
    <div>Update</div>
  )
}
