export const colorConfigs = {
    buttonColor:"#ffbfb5",
    landing_page_lower:"#161c8e",
    landing_page_upper:"#572aba",
    sign_option_upper:"#9982d4",
    sign_option_lower:"#3c48ec",
    navbar_bg:"#3c48ec",
    nav_options:"#ffbfb5",
    chat_input:"#9981cd",
}