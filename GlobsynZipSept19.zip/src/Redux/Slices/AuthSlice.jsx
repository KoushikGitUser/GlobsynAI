import { createSlice } from "@reduxjs/toolkit";

export const AuthSlice = createSlice({
    name:"AuthSlice",
    initialState:{},
    reducers:{

    },
    extraReducers:(builder)=>{

    }
})

export default AuthSlice;